# 依赖包
import os
import numpy as np
import torch
from .parameter_config import Config
from .real_dse_data import RdseData
from .complex_dse_data import CdseData
from .bse_data import BseData
from .phy_data import PhyData


def torch_to_numpy(tensor):
    if tensor is None:
        return None
    return tensor.detach().cpu().numpy()

def numpy_to_tensor(array):
    if array is None:
        return None
    return torch.tensor(array)


def _to_serializable_scalar(value):
    if value is None:
        return None
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        if value.ndim == 0:
            return value.detach().cpu().item()
        return value.detach().cpu().numpy()
    return value


def _serialize_field(data, key, value):
    if isinstance(value, torch.Tensor):
        data[key] = torch_to_numpy(value)
    else:
        data[key] = _to_serializable_scalar(value)


def _maybe_load(z, key):
    if key not in z:
        return None
    value = z[key]
    if isinstance(value, np.ndarray) and value.ndim == 0:
        return value.item()
    return value

def random_color():
    color = np.random.rand(3)
    color[np.random.randint(3)] *= 0.5
    return color

def save_data(result, out_dir, prefix):
    path = rf'{out_dir}/{prefix}.npz'
    target_dir = os.path.dirname(path)
    if target_dir:
        os.makedirs(target_dir, exist_ok=True)
    data = {}
    if isinstance(result, Config):
        data.update({
            # model config
            'omega': result.omega,
            'D': result.D,
            'mt': result.mt,
            'lambda_square': result.lambda_square,
            'mu': result.mu,
            'nf': result.nf,
            'lambda_qcd': result.lambda_qcd,
            'm': result.m,
        })

    if isinstance(result, RdseData):
        rdse_fields = {
            'rdse_nk': result.nk,
            'rdse_nz': result.nz,
            'rdse_error': result.error,
            'rdse_kp': result.kp,
            'rdse_kw': result.kw,
            'rdse_zp': result.zp,
            'rdse_zw': result.zw,
            'rdse_z2': result.z2,
            'rdse_z4': result.z4,
            'rdse_a': result.a,
            'rdse_b': result.b,
            'rdse_c': result.c,
            'rdse_d': result.d,
            'rdse_renorm_pos': result.renorm_pos,
            'rdse_w0_interp': result.w0_interp,
            'rdse_w1_interp': result.w1_interp,
        }
        for key, value in rdse_fields.items():
            _serialize_field(data, key, value)

    if isinstance(result, CdseData):
        cdse_fields = {
            'cdse_error': result.error,
            'cdse_nk_contour': result.nk_contour,
            'cdse_nz_contour': result.nz_contour,
            'cdse_big_m_contour': result.big_m_contour,
            'cdse_eta_contour': result.eta_contour,
            'cdse_nk_inter': result.nk_inter,
            'cdse_nz_inter': result.nz_inter,
            'cdse_big_m_inter': result.big_m_inter,
            'cdse_eta_inter': result.eta_inter,
            'cdse_goal': result.goal,
            'cdse_kp_inter': result.kp_inter,
            'cdse_kw_inter': result.kw_inter,
            'cdse_zp_inter': result.zp_inter,
            'cdse_zw_inter': result.zw_inter,
            'cdse_kp_contour': result.kp_contour,
            'cdse_kw_contour': result.kw_contour,
            'cdse_zp_contour': result.zp_contour,
            'cdse_zw_contour': result.zw_contour,
            'cdse_u_jacobian': result.u_jacobian,
            'cdse_d_jacobian': result.d_jacobian,
            'cdse_r_jacobian': result.r_jacobian,
            'cdse_a_inter': result.a_inter,
            'cdse_b_inter': result.b_inter,
            'cdse_a_up': result.a_up,
            'cdse_b_up': result.b_up,
            'cdse_a_down': result.a_down,
            'cdse_b_down': result.b_down,
            'cdse_a_right': result.a_right,
            'cdse_b_right': result.b_right,
            'cdse_a_goal': result.a_goal,
            'cdse_b_goal': result.b_goal,
        }
        for key, value in cdse_fields.items():
            _serialize_field(data, key, value)

    if isinstance(result, BseData):
        bse_fields = {
            'bse_error': result.error,
            'bse_nk_inter': result.eigenvector.shape[0] if result.eigenvector is not None else None,
            'bse_nz_inter': result.eigenvector.shape[1] if result.eigenvector is not None else None,
            'bse_eigenvalue': result.eigenvalue,
            'bse_eigenvector': result.eigenvector,
            'bse_kernel': result.kernel,
        }
        for key, value in bse_fields.items():
            _serialize_field(data, key, value)

    if isinstance(result, PhyData):
        phy_fields = {
            'phy_vacuum_quark_condensation': result.vacuum_quark_condensation,
            'phy_lepton_decay_constant': result.lepton_decay_constant,
        }
        for key, value in phy_fields.items():
            _serialize_field(data, key, value)
        
    np.savez_compressed(path, **data)
    return None

def load_data(
    out_dir,
    prefix,
    config=None,
    rdse: RdseData = None,
    cdse: CdseData = None,
    bse: BseData = None,
    phy_data: PhyData = None,):
    path = rf"{out_dir}/{prefix}.npz"
    z = np.load(path, allow_pickle=True)
    
    # 无条件加载 config
    if isinstance(config, Config):
        for key in ['omega', 'D', 'mt', 'lambda_square', 'mu', 'nf', 'lambda_qcd', 'm']:
            if key in z:
                value = z[key]
                setattr(config, key, value.item() if isinstance(value, np.ndarray) else value)
    
    # 加载 RdseData 属性
    if rdse is not None:
        tensor_keys = ['kp', 'kw', 'zp', 'zw', 'a', 'b', 'c', 'd']
        scalar_keys = ['nk', 'nz', 'error', 'z2', 'z4', 'renorm_pos', 'w0_interp', 'w1_interp']
        for key in tensor_keys:
            full_key = 'rdse_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(rdse, key, numpy_to_tensor(value))
        for key in scalar_keys:
            full_key = 'rdse_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(rdse, key, value)
                    
    # 加载 CdseData 属性
    if cdse is not None:
        tensor_keys = ['goal', 'kp_inter', 'kw_inter', 'zp_inter', 'zw_inter', 'kp_contour', 'kw_contour', 'zp_contour', 'zw_contour', 'u_jacobian', 'd_jacobian', 'r_jacobian', 'a_inter', 'b_inter', 'a_up', 'b_up', 'a_down', 'b_down', 'a_right', 'b_right', 'a_goal', 'b_goal']
        scalar_keys = ['error', 'nk_contour', 'nz_contour', 'big_m_contour', 'eta_contour', 'nk_inter', 'nz_inter', 'big_m_inter', 'eta_inter']
        
        for key in tensor_keys:
            full_key = 'cdse_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(cdse, key, numpy_to_tensor(value))
        
        for key in scalar_keys:
            full_key = 'cdse_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(cdse, key, value)
                    
    # 加载 BseData 属性
    if bse is not None:
        tensor_keys_bse = ['eigenvalue', 'eigenvector', 'kernel']
        scalar_keys_bse = ['error']
        
        for key in tensor_keys_bse:
            full_key = 'bse_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(bse, key, numpy_to_tensor(value))
        for key in scalar_keys_bse:
            full_key = 'bse_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(bse, key, value)

    if phy_data is not None:
        for key in ['vacuum_quark_condensation', 'lepton_decay_constant']:
            full_key = 'phy_' + key
            value = _maybe_load(z, full_key)
            if value is not None:
                setattr(phy_data, key, value)

    return None
