# 依赖包
import torch
from dataclasses import dataclass, field
import numpy as np

@dataclass
class PhyData():
    vacuum_quark_condensation: float = 0.0
    lepton_decay_constant: float = 0.0

    def __post_init__(self):
        pass