# 参数包
from .parameter_config import Config

# 依赖包
import torch
from dataclasses import dataclass, field
import numpy as np

@dataclass
class CdseData(Config):

        # Cdse Config
        error: float = 1e-7
        
        nk_contour: int = 40
        nz_contour: int = 24
        big_m_contour: float = 0.134
        eta_contour: float = 0.5

        nk_inter: int = 0
        nz_inter: int = 0
        big_m_inter: float = 0.134
        eta_inter: float = 0.5

        goal: torch.Tensor | None = field(default=None)

        kp_inter: torch.Tensor | None = field(default=None, init=False)
        kw_inter: torch.Tensor | None = field(default=None, init=False)
        zp_inter: torch.Tensor | None = field(default=None, init=False)
        zw_inter: torch.Tensor | None = field(default=None, init=False)

        kp_contour: torch.Tensor | None = field(default=None, init=False)
        kw_contour: torch.Tensor | None = field(default=None, init=False)
        zp_contour: torch.Tensor | None = field(default=None, init=False)
        zw_contour: torch.Tensor | None = field(default=None, init=False)

        u_jacobian: torch.Tensor | None = field(default=None, init=False)
        d_jacobian: torch.Tensor | None = field(default=None, init=False)
        r_jacobian: torch.Tensor | None = field(default=None, init=False)


        # Normal Results
        a_inter: torch.Tensor | None = field(default=None, init=False)
        b_inter: torch.Tensor | None = field(default=None, init=False)
        a_up: torch.Tensor | None = field(default=None, init=False)
        b_up: torch.Tensor | None = field(default=None, init=False)
        a_down: torch.Tensor | None = field(default=None, init=False)
        b_down: torch.Tensor | None = field(default=None, init=False)
        a_right: torch.Tensor | None = field(default=None, init=False)
        b_right: torch.Tensor | None = field(default=None, init=False)

        a_goal: torch.Tensor | None = field(default=None, init=False)
        b_goal: torch.Tensor | None = field(default=None, init=False)

        def __post_init__(self):
            super().__post_init__()
            self.kp_contour, self.kw_contour = self._create_legendre_kp(self.nk_contour)
            self.zp_contour, self.zw_contour = self._create_legendre_zp(self.nz_contour)

            self.u_jacobian = -1 - 1j * self.eta_contour * self.big_m_contour / torch.sqrt(self.kp_contour).view(1, 1, -1)
            self.d_jacobian = 1 - 1j * self.eta_contour * self.big_m_contour / torch.sqrt(self.kp_contour).view(1, 1, -1)
            self.r_jacobian = 1j * self.big_m_contour * np.sqrt(self.lambda_square) * 2 * self.eta_contour

            self.a_up = torch.ones(self.nk_contour, dtype=torch.complex128)
            self.b_up = torch.ones(self.nk_contour, dtype=torch.complex128)
            self.a_down = torch.ones(self.nk_contour, dtype=torch.complex128)
            self.b_down = torch.ones(self.nk_contour, dtype=torch.complex128)
            self.a_right = torch.ones(self.nz_contour, dtype=torch.complex128)
            self.b_right = torch.ones(self.nz_contour, dtype=torch.complex128)