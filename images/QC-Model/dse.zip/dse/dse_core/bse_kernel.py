import torch
import numpy as np
from .real_dse_data import RdseData
from .complex_dse_data import CdseData
from .bse_data import BseData

class BseSolver:

    @staticmethod
    def __pi_kernel(i, j, rdse1_data: RdseData, rdse2_data: RdseData, cdse1_data: CdseData, cdse2_data: CdseData):
        big_p = cdse1_data.big_m_inter
        k = cdse1_data.kp_inter.view(-1, 1, 1, 1, 1)
        q = cdse1_data.kp_inter.view(1, 1, -1, 1, 1)
        zk = cdse1_data.zp_inter.view(1, -1, 1, 1, 1)
        zq = cdse1_data.zp_inter.view(1, 1, 1, 1, -1)
        y = cdse1_data.zp_inter.view(1, 1, 1, -1, 1)
        apu = cdse1_data.a_inter.detach().clone().view(1, 1, cdse1_data.nk_inter, 1, cdse1_data.nz_inter)
        bpu = cdse1_data.b_inter.detach().clone().view(1, 1, cdse1_data.nk_inter, 1, cdse1_data.nz_inter)
        ams = cdse2_data.a_inter.detach().clone().flip(1).view(1, 1, cdse2_data.nk_inter, 1, cdse2_data.nz_inter)
        bms = cdse2_data.b_inter.detach().clone().flip(1).view(1, 1, cdse2_data.nk_inter, 1, cdse2_data.nz_inter)

        pair_k_k = k
        pair_k_q = torch.sqrt(k * q) * (zk * zq + y * torch.sqrt(1 - zk ** 2) * torch.sqrt(1 - zq ** 2))
        pair_k_bigp = 1j * torch.sqrt(k) * big_p * zk
        pair_q_q = q
        pair_q_bigp = 1j * torch.sqrt(q) * big_p * zq
        pair_bigp_bigp = -big_p ** 2
        kq = pair_k_k + pair_q_q - 2*pair_k_q
        GLPP = rdse1_data.z2 * rdse2_data.z2 * rdse1_data._g(kq)

        nKerPS = 4
        idx = nKerPS * i + j + 1
        if idx == 1:
            return (16 * GLPP * (4 * bms * bpu - ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q))/((ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 2:
            return (32 * GLPP * ((apu * bms + ams * bpu) * pair_bigp_bigp + 2 * (apu * bms - ams * bpu) * pair_q_bigp))/((ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 3:
            return (32 * GLPP * pair_q_bigp * ((apu * bms + ams * bpu) * pair_q_bigp + 2 * (apu * bms - ams * bpu) * pair_q_q))/((ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 4:
            return (64 * ams * apu * GLPP * (pow(pair_q_bigp,2) - pair_bigp_bigp * pair_q_q))/((ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 5:
            return (32 * GLPP * (-(pow(pair_k_k,2) * ((apu * bms + ams * bpu) * pair_bigp_bigp + 2 * (apu * bms - ams * bpu) * pair_q_bigp)) + pair_k_k * ((apu * bms + ams * bpu) * pow(pair_k_bigp,2) - 2 * apu * bms * pow(pair_q_bigp,2) - 2 * ams * bpu * pow(pair_q_bigp,2) + 2 * pair_k_q * ((apu * bms + ams * bpu) * pair_bigp_bigp + 4 * (apu * bms - ams * bpu) * pair_q_bigp) + 2 * pair_k_bigp * ((apu * bms - ams * bpu) * pair_k_q + (apu * bms + ams * bpu) * pair_q_bigp) - apu * bms * pair_bigp_bigp * pair_q_q - ams * bpu * pair_bigp_bigp * pair_q_q - 6 * apu * bms * pair_q_bigp * pair_q_q + 6 * ams * bpu * pair_q_bigp * pair_q_q) + pair_k_bigp * (-((apu * bms + ams * bpu) * pair_k_bigp * (4 * pair_k_q - pair_q_q)) + 2 * pair_k_q * ((-4 * apu * bms + 4 * ams * bpu) * pair_k_q + (apu * bms + ams * bpu) * pair_q_bigp + 3 * (apu * bms - ams * bpu) * pair_q_q))))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 6:
            return (16 * GLPP * (pow(pair_k_k,2) * (-(ams * apu * pow(pair_bigp_bigp,2)) + 8 * ams * apu * pow(pair_q_bigp,2) + 4 * pair_bigp_bigp * (bms * bpu - ams * apu * pair_q_q)) + pair_k_bigp * (2 * pair_k_q * pair_q_bigp * (-4 * bms * bpu + 16 * ams * apu * pair_k_q + ams * apu * pair_bigp_bigp - 8 * ams * apu * pair_q_q) - pair_k_bigp * (4 * pair_k_q - pair_q_q) * (-4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q)) + pair_k_k * (8 * bms * bpu * pow(pair_q_bigp,2) - 2 * ams * apu * pair_bigp_bigp * pow(pair_q_bigp,2) + 4 * bms * bpu * pair_bigp_bigp * pair_q_q - ams * apu * pow(pair_bigp_bigp,2) * pair_q_q + 16 * ams * apu * pow(pair_q_bigp,2) * pair_q_q - 4 * ams * apu * pair_bigp_bigp * pow(pair_q_q,2) + pow(pair_k_bigp,2) * (-4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) + 2 * pair_k_bigp * pair_q_bigp * (-4 * bms * bpu - 4 * ams * apu * pair_k_q + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) + pair_k_q * (2 * ams * apu * pow(pair_bigp_bigp,2) - 32 * ams * apu * pow(pair_q_bigp,2) + pair_bigp_bigp * (-8 * bms * bpu + 8 * ams * apu * pair_q_q)))))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 7:
            return (16 * GLPP * pair_q_bigp * (pow(pair_k_k,2) * pair_q_bigp * (4 * bms * bpu - ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) + pair_k_bigp * (2 * ams * apu * pair_k_bigp * pair_q_bigp * pair_q_q + 4 * pow(pair_k_q,2) * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) - pair_k_q * (8 * ams * apu * pair_k_bigp * pair_q_bigp - 4 * ams * apu * pow(pair_q_bigp,2) + 3 * pair_q_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q))) + pair_k_k * (2 * ams * apu * pow(pair_k_bigp,2) * pair_q_bigp - pair_k_bigp * (-4 * ams * apu * pow(pair_q_bigp,2) + pair_k_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q)) + pair_q_bigp * (-4 * ams * apu * pow(pair_q_bigp,2) - 16 * pair_k_q * (bms * bpu + ams * apu * pair_q_q) + pair_q_q * (12 * bms * bpu + ams * apu * pair_bigp_bigp + 12 * ams * apu * pair_q_q)))))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 8:
            return (32 * GLPP * (2 * (apu * bms + ams * bpu) * pow(pair_k_k,2) * (pow(pair_q_bigp,2) - pair_bigp_bigp * pair_q_q) + pair_k_bigp * (4 * pow(pair_k_q,2) * ((apu * bms - ams * bpu) * pair_bigp_bigp + 2 * (apu * bms + ams * bpu) * pair_q_bigp) + pair_k_bigp * pair_q_q * ((apu * bms - ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q) - pair_k_q * ((-2 * apu * bms + 2 * ams * bpu) * pow(pair_q_bigp,2) + 3 * (apu * bms - ams * bpu) * pair_bigp_bigp * pair_q_q + 2 * (apu * bms + ams * bpu) * pair_q_bigp * pair_q_q + 4 * pair_k_bigp * ((apu * bms - ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q))) + pair_k_k * (pow(pair_k_bigp,2) * ((apu * bms - ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q) - 2 * ((apu * bms - ams * bpu) * pair_q_bigp - (apu * bms + ams * bpu) * pair_q_q) * (pow(pair_q_bigp,2) - pair_bigp_bigp * pair_q_q) + pair_k_bigp * (-(pair_k_q * ((apu * bms - ams * bpu) * pair_bigp_bigp + 2 * (apu * bms + ams * bpu) * pair_q_bigp)) + 2 * pair_q_bigp * ((apu * bms - ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q)) + 2 * pair_k_q * (-4 * (apu * bms + ams * bpu) * pow(pair_q_bigp,2) + pair_bigp_bigp * ((-(apu * bms) + ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q)))))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 9:
            return (64 * GLPP * ((apu * bms + ams * bpu) * pow(pair_k_bigp,3) + 2 * pow(pair_k_bigp,2) * ((apu * bms - ams * bpu) * pair_k_q - (apu * bms + ams * bpu) * pair_q_bigp + (-(apu * bms) + ams * bpu) * pair_q_q) + pair_k_bigp * (-(pair_k_k * ((apu * bms + ams * bpu) * pair_bigp_bigp + (-(apu * bms) + ams * bpu) * pair_q_bigp)) + pair_k_q * ((apu * bms + ams * bpu) * pair_bigp_bigp + 4 * (-(apu * bms) + ams * bpu) * pair_q_bigp) + pair_q_bigp * ((apu * bms + ams * bpu) * pair_q_bigp + 3 * (apu * bms - ams * bpu) * pair_q_q)) + pair_bigp_bigp * (pair_k_k * ((-3 * apu * bms + 3 * ams * bpu) * pair_k_q + (apu * bms + ams * bpu) * pair_q_bigp + 2 * (apu * bms - ams * bpu) * pair_q_q) + pair_k_q * (4 * (apu * bms - ams * bpu) * pair_k_q - (apu * bms + ams * bpu) * pair_q_bigp + 3 * (-(apu * bms) + ams * bpu) * pair_q_q))))/(3. * pair_k_bigp * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 10:
            return (32 * GLPP * (2 * pow(pair_k_bigp,2) * (4 * bms * bpu - 4 * ams * apu * pair_k_q - ams * apu * pair_bigp_bigp) * pair_q_bigp + pow(pair_k_bigp,3) * (-4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) + pair_bigp_bigp * pair_q_bigp * (pair_k_k * (-4 * bms * bpu + 12 * ams * apu * pair_k_q + ams * apu * pair_bigp_bigp - 4 * ams * apu * pair_q_q) + pair_k_q * (4 * bms * bpu - 16 * ams * apu * pair_k_q - ams * apu * pair_bigp_bigp + 8 * ams * apu * pair_q_q)) + pair_k_bigp * (pow(pair_q_bigp,2) * (-4 * bms * bpu + ams * apu * pair_bigp_bigp - 8 * ams * apu * pair_q_q) + pair_k_k * (-(ams * apu * pow(pair_bigp_bigp,2)) - 4 * ams * apu * pow(pair_q_bigp,2) + 4 * pair_bigp_bigp * (bms * bpu - ams * apu * pair_q_q)) + pair_k_q * (ams * apu * pow(pair_bigp_bigp,2) + 16 * ams * apu * pow(pair_q_bigp,2) + pair_bigp_bigp * (-4 * bms * bpu + 4 * ams * apu * pair_q_q)))))/(3. * pair_k_bigp * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 11:
            return (16 * GLPP * pair_q_bigp * (4 * ams * apu * pow(pair_k_bigp,3) * pair_q_bigp - 2 * pow(pair_k_bigp,2) * (4 * ams * apu * pow(pair_q_bigp,2) + pair_k_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) - pair_q_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q)) - pair_k_bigp * pair_q_bigp * (-4 * ams * apu * pow(pair_q_bigp,2) + 12 * bms * bpu * pair_q_q + 3 * ams * apu * pair_bigp_bigp * pair_q_q + 12 * ams * apu * pow(pair_q_q,2) - 8 * pair_k_q * (2 * bms * bpu + ams * apu * pair_bigp_bigp + 2 * ams * apu * pair_q_q) + pair_k_k * (4 * bms * bpu + 5 * ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q)) + pair_bigp_bigp * (pair_k_k * (4 * ams * apu * pow(pair_q_bigp,2) + 3 * pair_k_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) - 2 * pair_q_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q)) + pair_k_q * (-4 * ams * apu * pow(pair_q_bigp,2) - 4 * pair_k_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q) + 3 * pair_q_q * (4 * bms * bpu + ams * apu * pair_bigp_bigp + 4 * ams * apu * pair_q_q)))))/(3. * pair_k_bigp * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 12:
            return (32 * GLPP * (2 * pow(pair_k_bigp,3) * ((apu * bms - ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q) - 2 * pow(pair_k_bigp,2) * (2 * (apu * bms - ams * bpu) * pow(pair_q_bigp,2) + pair_k_q * ((apu * bms - ams * bpu) * pair_bigp_bigp + 2 * (apu * bms + ams * bpu) * pair_q_bigp) + (-(apu * bms) + ams * bpu) * pair_bigp_bigp * pair_q_q + 2 * (apu * bms + ams * bpu) * pair_q_bigp * pair_q_q) - pair_k_bigp * (pair_q_bigp * ((-2 * apu * bms + 2 * ams * bpu) * pow(pair_q_bigp,2) + 3 * (apu * bms - ams * bpu) * pair_bigp_bigp * pair_q_q + 2 * (apu * bms + ams * bpu) * pair_q_bigp * pair_q_q) - 2 * pair_k_q * (4 * (apu * bms + ams * bpu) * pow(pair_q_bigp,2) + pair_bigp_bigp * (3 * (apu * bms - ams * bpu) * pair_q_bigp + 2 * (apu * bms + ams * bpu) * pair_q_q)) + pair_k_k * (2 * (apu * bms + ams * bpu) * pow(pair_q_bigp,2) + pair_bigp_bigp * (3 * (apu * bms - ams * bpu) * pair_q_bigp + 4 * (apu * bms + ams * bpu) * pair_q_q))) + pair_bigp_bigp * (pair_k_q * ((-2 * apu * bms + 2 * ams * bpu) * pow(pair_q_bigp,2) - 4 * pair_k_q * ((apu * bms - ams * bpu) * pair_bigp_bigp + 2 * (apu * bms + ams * bpu) * pair_q_bigp) + 3 * (apu * bms - ams * bpu) * pair_bigp_bigp * pair_q_q + 2 * (apu * bms + ams * bpu) * pair_q_bigp * pair_q_q) + pair_k_k * (3 * pair_k_q * ((apu * bms - ams * bpu) * pair_bigp_bigp + 2 * (apu * bms + ams * bpu) * pair_q_bigp) + 2 * (apu * bms - ams * bpu) * (pow(pair_q_bigp,2) - pair_bigp_bigp * pair_q_q)))))/(3. * pair_k_bigp * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 13:
            return (64 * ams * apu * GLPP * (2 * pow(pair_k_bigp,2) * pair_q_q + pair_k_q * pair_bigp_bigp * pair_q_q - pair_k_bigp * pair_q_bigp * (2 * pair_k_q + pair_q_q) + pair_k_k * (pair_k_q * pair_bigp_bigp - pair_k_bigp * pair_q_bigp + 2 * pow(pair_q_bigp,2) - 2 * pair_bigp_bigp * pair_q_q)))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 14:
            return (-64 * (apu * bms + ams * bpu) * GLPP * (2 * pow(pair_k_bigp,2) * pair_q_q + pair_k_q * pair_bigp_bigp * pair_q_q - pair_k_bigp * pair_q_bigp * (2 * pair_k_q + pair_q_q) + pair_k_k * (pair_k_q * pair_bigp_bigp - pair_k_bigp * pair_q_bigp + 2 * pow(pair_q_bigp,2) - 2 * pair_bigp_bigp * pair_q_q)))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 15:
            return (32 * (apu * bms - ams * bpu) * GLPP * pair_q_bigp * (2 * pow(pair_k_bigp,2) * pair_q_q + pair_k_q * pair_bigp_bigp * pair_q_q - pair_k_bigp * pair_q_bigp * (2 * pair_k_q + pair_q_q) + pair_k_k * (pair_k_q * pair_bigp_bigp - pair_k_bigp * pair_q_bigp + 2 * pow(pair_q_bigp,2) - 2 * pair_bigp_bigp * pair_q_q)))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        elif idx == 16:
            return (16 * GLPP * (4 * bms * bpu + ams * apu * pair_bigp_bigp - 4 * ams * apu * pair_q_q) * (-2 * pow(pair_k_bigp,2) * pair_q_q - pair_k_q * pair_bigp_bigp * pair_q_q + pair_k_bigp * pair_q_bigp * (2 * pair_k_q + pair_q_q) + pair_k_k * (-(pair_k_q * pair_bigp_bigp) + pair_k_bigp * pair_q_bigp - 2 * pow(pair_q_bigp,2) + 2 * pair_bigp_bigp * pair_q_q)))/(3. * (pow(pair_k_bigp,2) - pair_k_k * pair_bigp_bigp) * (pair_k_k - 2 * pair_k_q + pair_q_q) * (ams ** 2 * pair_bigp_bigp + 4 * (bms ** 2 - ams ** 2 * pair_q_bigp + ams ** 2 * pair_q_q)) * (apu ** 2 * pair_bigp_bigp + 4 * (bpu ** 2 + apu ** 2 * pair_q_bigp + apu ** 2 * pair_q_q)))
        raise ValueError('invalid indices')

    @staticmethod
    def __pre_cal_kernel(rdse1_data: RdseData, rdse2_data: RdseData, cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData):

        K_list = []
        qyw_torch = cdse1_data.zw_inter.view(1, 1, 1, -1, 1) 
        
        for i in range(4):
            row = []
            for j in range(4):
                # 直接计算出一个元素 (p, pz, q, qy, qz)
                kernel_element = BseSolver.__pi_kernel(i, j, rdse1_data, rdse2_data, cdse1_data, cdse2_data)
                integrated_element = torch.sum(qyw_torch * kernel_element / 2, dim = 3)
                row.append(integrated_element)

            K_list.append(torch.stack(row, dim=-1))
            
        bse_data.kernel = torch.stack(K_list, dim=-2)

    @staticmethod
    def __cal_eigen(cdse_data: CdseData, bse_data: BseData):
        """
        计算BSE的特征值
        """
        # pre_kernel: p, pz, q, qz, 4, 4
        # f: p, pz, 4
        kq_torch = cdse_data.kp_inter.view(1, 1, -1, 1, 1, 1)
        qw_torch = cdse_data.kw_inter.view(1, 1, -1, 1, 1, 1)
        qz_torch = cdse_data.zp_inter.view(1, 1, 1, -1, 1, 1)
        qzw_torch = cdse_data.zw_inter.view(1, 1, 1, -1, 1, 1)

        weight = (2 * np.pi) ** (-3) * qw_torch * kq_torch * qzw_torch * torch.sqrt(1 - qz_torch ** 2)

        f_stay = bse_data.eigenvector
        f_old = f_stay.view(1, 1, cdse_data.nk_inter, cdse_data.nz_inter, 4, 1)

        kernel_weighted = bse_data.kernel * weight  # p, pz, q, qz, 4, 4
        mat_vec_prod = torch.matmul(kernel_weighted, f_old) # (..., 4, 4) @ (..., 4, 1) -> (..., 4, 1)
        f_new = torch.sum(mat_vec_prod, dim=(2, 3)) # p, pz, 4, 1
        f_new = f_new.squeeze(-1)    # p, pz, 4
        comp_num = torch.sum(torch.conj(f_stay) * f_new, dim=(0, 1, 2))  # (nk, nz)
        comp_den = torch.sum(torch.conj(f_stay) * f_stay, dim=(0, 1, 2))  # (nk, nz)
        bse_data.eigenvalue = comp_num / comp_den
        bse_data.eigenvector = f_new / f_new[0, 0, 0]
        return None
        
    @staticmethod
    def iter(rdse1_data: RdseData, rdse2_data: RdseData, cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData):
        print("-"*20+"Calculate BS Kernel"+"-"*20)
        BseSolver.__pre_cal_kernel(rdse1_data, rdse2_data, cdse1_data, cdse2_data, bse_data)
        error_curr = 100
        step = 0
        
        while error_curr > bse_data.error:
            step += 1
            old_eigenvalue = bse_data.eigenvalue
            BseSolver.__cal_eigen(cdse1_data, bse_data)
            error_curr = torch.abs(bse_data.eigenvalue - old_eigenvalue)
            print(f'state:BSE\tstep:{step}\terror:{error_curr}\tgoal:{bse_data.error}\teigenvalue:{bse_data.eigenvalue}')
        return None
        
    @staticmethod
    def __norm_kernel(pz, cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData):

        k = cdse1_data.kp_inter.view(-1, 1)
        kz = cdse1_data.zp_inter.view(1, -1)
        p = cdse1_data.big_m_inter

        apu = cdse1_data.a_inter.detach().clone()
        bpu = cdse1_data.b_inter.detach().clone()
        ams = cdse2_data.a_inter.detach().clone().flip(1)
        bms = cdse2_data.b_inter.detach().clone().flip(1)

        f1 = bse_data.eigenvector[:, :, 0]
        f2 = bse_data.eigenvector[:, :, 1]
        f3 = bse_data.eigenvector[:, :, 2]
        f4 = bse_data.eigenvector[:, :, 3]

        pair_bigp_bigp = -p ** 2
        pairkZ = 1j * kz * torch.sqrt(k) * pz
        pairPZ = -p * pz
        pairZZ = -pz ** 2
        pair_k_bigp = 1j * kz * torch.sqrt(k) * p
        pair_k_k = k
        return (96*(-4*bms*bpu*pow(f1,2) + ams*apu*pow(f1,2)*pair_bigp_bigp + pow(pairkZ,2)*(8*ams*apu*pow(f2,2) + 8*bms*bpu*f2*f3 + 8*apu*bms*f2*f4 + 8*ams*bpu*f2*f4 + 4*bms*bpu*pow(f4,2) + 4*(-(apu*bms) + ams*bpu)*f3*f4*pair_k_bigp - 2*ams*apu*pow(f3,2)*pow(pair_k_bigp,2) + ams*apu*(2*f2*f3 - pow(f4,2))*pair_bigp_bigp) - 4*apu*bms*f1*f2*pairPZ - 4*ams*bpu*f1*f2*pairPZ - 2*ams*apu*pow(f2,2)*pow(pairPZ,2) - 4*pairkZ*((apu*bms - ams*bpu)*f2*(2*f1 - f4*pairPZ) + pair_k_bigp*(f1*(apu*bms*f3 + ams*bpu*f3 + 2*ams*apu*f4) + ams*apu*(f2*f3 - pow(f4,2))*pairPZ)) + 4*bms*bpu*pow(f2,2)*pairZZ - 4*apu*bms*f2*f4*pair_k_bigp*pairZZ + 4*ams*bpu*f2*f4*pair_k_bigp*pairZZ - 2*ams*apu*pow(f4,2)*pow(pair_k_bigp,2)*pairZZ + ams*apu*pow(f2,2)*pair_bigp_bigp*pairZZ + 4*ams*apu*pow(pair_k_k,2)*(pow(f3,2)*pow(pairkZ,2) + pow(f4,2)*pairZZ) + pair_k_k*(-4*ams*apu*pow(f1,2) + pow(pairkZ,2)*(8*ams*apu*f2*f3 + 4*bms*bpu*pow(f3,2) - 4*ams*apu*pow(f4,2) + ams*apu*pow(f3,2)*pair_bigp_bigp) + 8*ams*apu*f1*f4*pairPZ - 2*ams*apu*pow(f4,2)*pow(pairPZ,2) - 4*(apu*bms - ams*bpu)*f3*pairkZ*(2*f1 - f4*pairPZ) - 4*ams*apu*pow(f2,2)*pairZZ - 8*apu*bms*f2*f4*pairZZ - 8*ams*bpu*f2*f4*pairZZ - 4*bms*bpu*pow(f4,2)*pairZZ + ams*apu*pow(f4,2)*pair_bigp_bigp*pairZZ)))/((4*pow(bms,2) + 4*pow(ams,2)*pair_k_k - 4*pow(ams,2)*pair_k_bigp + pow(ams,2)*pair_bigp_bigp)*(4*pow(bpu,2) + 4*pow(apu,2)*pair_k_k + 4*pow(apu,2)*pair_k_bigp + pow(apu,2)*pair_bigp_bigp))
    
    @staticmethod
    def norm(cdse1_s_data: CdseData, cdse2_s_data: CdseData, cdse1_b_data: CdseData, cdse2_b_data: CdseData, bse_data: BseData):
        """
        归一化本征向量
        """
        
        term1 = BseSolver.__norm_kernel(cdse1_s_data.big_m_inter, cdse1_s_data, cdse2_s_data, bse_data)
        # 另一组数据
        term2 = BseSolver.__norm_kernel(cdse1_s_data.big_m_inter, cdse1_b_data, cdse2_b_data, bse_data)

        kq_torch = cdse1_s_data.kp_inter.view(-1, 1)
        qw_torch = cdse1_s_data.kw_inter.view(-1, 1)
        qz_torch = cdse1_s_data.zp_inter.view(1, -1)
        qzw_torch = cdse1_s_data.zw_inter.view(1, -1)

        weight = (2 * np.pi) ** (-3) * qw_torch * kq_torch * qzw_torch * torch.sqrt(1 - qz_torch ** 2)

        coeff = abs(torch.sum(weight * (term1 - term2) / (cdse1_b_data.big_m_inter ** 2 - cdse1_s_data.big_m_inter ** 2))) ** (-0.5)

        bse_data.eigenvector *= coeff
        return None
