# 参数包
from .real_dse_data import RdseData
import torch
import numpy as np
import torch.nn as nn
from .complex_dse_data import CdseData

class CdseSolver:

    @staticmethod
    def change_inter_points(data: CdseData, eta: float = None, big_m: float = None, nk: int = None, nz: int = None):
        data.eta_inter = data.eta_contour if eta is None else eta
        data.big_m_inter = data.big_m_contour if big_m is None else big_m
        data.nk_inter = data.nk_contour if nk is None else nk
        data.kp_inter, data.kw_inter = data._create_legendre_kp(data.nk_inter)
        data.nz_inter = data.nz_contour if nz is None else nz
        data.zp_inter, data.zw_inter = data._create_legendre_zp(data.nz_inter)
        data.a_inter = torch.ones((data.nk_inter, data.nz_inter), dtype=torch.complex128)
        data.b_inter = torch.ones((data.nk_inter, data.nz_inter), dtype=torch.complex128)

    @staticmethod
    def __cal_contour_init(data: CdseData):
        CdseSolver.change_inter_points(data, data.eta_contour, data.big_m_contour, data.nk_contour, data.nz_contour)
        
    @staticmethod
    def __cal_right(rdse_data: RdseData, cdse_data: CdseData):
        """
        利用复DSE计算Ar, Br
        读取实DSE结果
        参数: mode: 'train' or 'test'
        更新Ar, Br
        """
        big_m = cdse_data.big_m_contour

        kp = cdse_data.kp_contour
        kw = cdse_data.kw_contour
        zp = cdse_data.zp_contour
        zw = cdse_data.zw_contour


        # pz, q, qy, qz
        dot_p_p = cdse_data.lambda_square - 1 / cdse_data.lambda_square
        dot_q_q = kp.view(1, -1, 1, 1)
        dot_bigp_bigp = -big_m ** 2
        zp_grid = zp.view(-1, 1, 1, 1)
        zq_grid = zp.view(1, 1, 1, -1)
        yq_grid = zp.view(1, 1, -1, 1)

        dot_p_bigp = 1j * big_m * np.sqrt(dot_p_p) * zp_grid
        dot_q_bigp = 1j * big_m * torch.sqrt(dot_q_q) * zq_grid
        dot_p_q = np.sqrt(dot_p_p) * torch.sqrt(dot_q_q) * (torch.sqrt(1 - zp_grid**2) * torch.sqrt(1 - zq_grid**2) * yq_grid +  zp_grid * zq_grid)

        a_temp = np.interp(kp.numpy(), rdse_data.kp.numpy(), rdse_data.a.numpy())
        b_temp = np.interp(kp.numpy(), rdse_data.kp.numpy(), rdse_data.b.numpy())

        a_temp = torch.tensor(a_temp, dtype=torch.complex128)
        b_temp = torch.tensor(b_temp, dtype=torch.complex128)

        psum_2 = dot_p_p + cdse_data.eta_contour ** 2 * dot_bigp_bigp + 2 * cdse_data.eta_contour * dot_p_bigp
        diff2_psum_q = psum_2 + dot_q_q - 2 * dot_p_q - 2 * cdse_data.eta_contour * dot_q_bigp
        demon = dot_q_q * a_temp.view(1, -1, 1, 1) ** 2 + b_temp.view(1, -1, 1, 1) ** 2
        g_val = cdse_data._g(diff2_psum_q)
        dot_psum_q = dot_p_q + cdse_data.eta_contour * dot_q_bigp
        diff_dot_q = dot_psum_q - dot_q_q
        diff_dot_psum = psum_2 - dot_psum_q
        proj_fa = dot_psum_q + 2 * diff_dot_q * diff_dot_psum / diff2_psum_q

        integrand_a = g_val * a_temp.view(1, -1, 1, 1) / demon * proj_fa
        integrand_b = g_val * b_temp.view(1, -1, 1, 1) / demon

        coeff_a = 4 * rdse_data.z2 ** 2 / (3 * psum_2.view(-1)) * (2 * np.pi)**(-3)
        coeff_b = 4 * rdse_data.z2 ** 2 * (2 * np.pi)**(-3)

        weight = kw.view(1, -1, 1, 1) * zw.view(1, 1, 1, -1) * zw.view(1, 1, -1, 1) * dot_q_q * torch.sqrt(1 - zq_grid**2) / 2

        sum_a = torch.sum(integrand_a * weight, dim=(1, 2, 3))
        sum_b = torch.sum(integrand_b * weight, dim=(1, 2, 3)) 

        cdse_data.a_right = rdse_data.z2 + coeff_a * sum_a
        cdse_data.b_right = rdse_data.z4 * rdse_data.m + coeff_b * sum_b

        return None

    @staticmethod
    def __cal_a_contour_b_contour(rdse_data: RdseData, cdse_data: CdseData):
        big_m = cdse_data.big_m_contour

        kp = cdse_data.kp_contour
        kw = cdse_data.kw_contour
        zp = cdse_data.zp_contour
        zw = cdse_data.zw_contour
        nk = cdse_data.nk_contour
        nz = cdse_data.nz_contour
        a = cdse_data.a_inter
        b = cdse_data.b_inter
            
        
        zpp_torch = torch.tensor([-1, 1], dtype=torch.int32)

        dot_bigp_bigp = -big_m ** 2
        dot_p_p = kp.view(-1, 1, 1, 1)
        zp_grid = zpp_torch.view(1, -1, 1, 1)
        dot_q_q = kp.view(1, 1, -1, 1)
        zq_grid = zp.view(1, 1, 1, -1)

        dot_p_bigp = 1j * big_m * torch.sqrt(dot_p_p) * zp_grid
        dot_q_bigp = 1j * big_m * torch.sqrt(dot_q_q) * zq_grid
        dot_p_q = torch.sqrt(dot_p_p) * torch.sqrt(dot_q_q) * zp_grid * zq_grid

        diff2_pq = dot_p_p + dot_q_q - 2 * dot_p_q
        qsum_2 = dot_q_q + cdse_data.eta_contour ** 2 * dot_bigp_bigp + 2 * cdse_data.eta_contour * dot_q_bigp
        dot_psum_qsum = dot_p_q + cdse_data.eta_contour * dot_p_bigp + cdse_data.eta_contour * dot_q_bigp +cdse_data.eta_contour ** 2 * dot_bigp_bigp
        diffpq_qsum = dot_p_q + cdse_data.eta_contour * dot_p_bigp - dot_q_q - cdse_data.eta_contour * dot_q_bigp
        diffpq_psum = dot_p_p + cdse_data.eta_contour * dot_p_bigp - dot_p_q -cdse_data.eta_contour * dot_q_bigp
        psum_2 = dot_p_p + cdse_data.eta_contour ** 2 * dot_bigp_bigp + 2 * cdse_data.eta_contour * dot_p_bigp
        demon = qsum_2 * a.view(1, 1, nk, nz) ** 2 + b.view(1, 1, nk, nz) ** 2
        g_val = cdse_data._g(diff2_pq)
        proj_fa = dot_psum_qsum + 2 * diffpq_qsum * diffpq_psum / diff2_pq
        integrand_a = g_val * a.view(1, 1, nk, nz) / demon * proj_fa
        integrand_b = g_val * b.view(1, 1, nk, nz) / demon

        coeff_a = 4 * rdse_data.z2 ** 2 / (3 * psum_2.view(nk, -1)) * (2 * np.pi)**(-3)
        coeff_b = 4 * rdse_data.z2 ** 2 * (2 * np.pi)**(-3)

        # dq * dzq * sqrt(1-zq**2) * q
        # p, pz, q, qz
        weight = kw.view(1, 1, -1, 1) * zw.view(1, 1, 1, -1) * dot_q_q * torch.sqrt(1 - zq_grid**2)

        sum_a = torch.sum(integrand_a * weight, dim=(2, 3))
        sum_b = torch.sum(integrand_b * weight, dim=(2, 3)) 

        res_a = rdse_data.z2 + coeff_a * sum_a
        res_b = rdse_data.z4 * rdse_data.m + coeff_b * sum_b

        cdse_data.a_down, cdse_data.a_up = res_a[:, 0], res_a[:, 1]
        cdse_data.b_down, cdse_data.b_up = res_b[:, 0], res_b[:, 1]

        return None

    @staticmethod
    def __cal_a_b_real(data: CdseData):

        kp_contour = data.kp_contour
        kp_inter = data.kp_inter
        kw = data.kw_contour
        zp_contour = data.zp_contour
        zp_inter = data.zp_inter
        zw = data.zw_contour
        a_up = data.a_up
        a_down = data.a_down
        a_right = data.a_right
        b_up = data.b_up
        b_down = data.b_down
        b_right = data.b_right
        u_factor = data.u_jacobian
        d_factor = data.d_jacobian
        r_factor = data.r_jacobian


        # p, zp; (qu, qd), zqr
        dot_qu_qu = kp_contour.view(1, 1, -1)
        dot_qd_qd = kp_contour.view(1, 1, -1)
        dot_qr_qr = data.lambda_square - 1 / data.lambda_square
        dot_bigp_contour_bigp_contour = -data.big_m_contour ** 2
        dot_bigp_inter_bigp_inter = -data.big_m_inter ** 2
        dot_p_p = kp_inter.view(-1, 1, 1)
        zqr_grid = zp_contour.view(1, 1, -1)
        zp_grid = zp_inter.view(1, -1, 1)

        dot_qu_bigp = 1j * torch.sqrt(dot_qu_qu) * data.big_m_contour
        dot_qd_bigp = -1j * torch.sqrt(dot_qd_qd) * data.big_m_contour
        dot_qr_bigp = 1j * np.sqrt(dot_qr_qr) * zqr_grid * data.big_m_contour

        dot_p_bigp = 1j * data.big_m_inter * torch.sqrt(dot_p_p) * zp_grid
        qusum_2 = dot_qu_qu + data.eta_contour ** 2 * dot_bigp_contour_bigp_contour + 2 * data.eta_contour * dot_qu_bigp
        qdsum_2 = dot_qd_qd + data.eta_contour ** 2 * dot_bigp_contour_bigp_contour + 2 * data.eta_contour * dot_qd_bigp
        qrsum_2 = dot_qr_qr + data.eta_contour ** 2 * dot_bigp_contour_bigp_contour + 2 * data.eta_contour * dot_qr_bigp
        psum_2 = dot_p_p + data.eta_inter ** 2 * dot_bigp_inter_bigp_inter + 2 * data.eta_inter * dot_p_bigp

        weight_u = kw.view(1, 1, -1) * u_factor
        weight_d = kw.view(1, 1, -1) * d_factor
        weight_r = zw.view(1, 1, -1) * r_factor

        demon_u = qusum_2 - psum_2
        demon_d = qdsum_2 - psum_2
        demon_r = qrsum_2 - psum_2

        numer_a = torch.sum(a_up * weight_u / demon_u + a_down * weight_d / demon_d, dim=(2)) + torch.sum(a_right * weight_r / demon_r, dim=(2))
        numer_b = torch.sum(b_up * weight_u / demon_u + b_down * weight_d / demon_d, dim=(2)) + torch.sum(b_right * weight_r / demon_r, dim=(2))

        norm = torch.sum(weight_u / demon_u + weight_d / demon_d, dim=(2)) + torch.sum(weight_r / demon_r, dim=(2))


        data.a_inter = numer_a / norm
        data.b_inter = numer_b / norm


        return None

    @staticmethod
    def iter(rdse_data: RdseData, cdse_data: CdseData):
        CdseSolver.__cal_contour_init(data = cdse_data)
        CdseSolver.__cal_right(rdse_data = rdse_data, cdse_data = cdse_data)
        error_curr = 100
        step = 0
        while error_curr > cdse_data.error:
            step = step + 1
            a_up_old = cdse_data.a_up.clone()
            a_down_old = cdse_data.a_down.clone()
            b_up_old = cdse_data.b_up.clone()
            b_down_old = cdse_data.b_down.clone()

            CdseSolver.__cal_a_b_real(data = cdse_data)
            CdseSolver.__cal_a_contour_b_contour(rdse_data = rdse_data, cdse_data = cdse_data)

            a_error = torch.mean(torch.abs(cdse_data.a_up - a_up_old)) + torch.mean(torch.abs(cdse_data.a_down - a_down_old))
            b_error = torch.mean(torch.abs(cdse_data.b_up - b_up_old)) + torch.mean(torch.abs(cdse_data.b_down - b_down_old))
            error_curr = a_error + b_error
            print(f"state:Complex DSE\tstep:{step}\terror:{error_curr}\tgoal:{cdse_data.error}")
        return None

    @staticmethod
    def cal_a_b(data: CdseData):
        CdseSolver.__cal_a_b_real(data = data)

    @staticmethod
    def __cal_a_b_straight(rdse_data: RdseData, cdse_data: CdseData):

        kp = cdse_data.kp_inter
        kw = cdse_data.kw_inter
        zp = cdse_data.zp_inter
        zw = cdse_data.zw_inter
        a = cdse_data.a_inter
        b = cdse_data.b_inter
        nk = cdse_data.nk_inter
        nz = cdse_data.nz_inter
        
        dot_p_p = kp.view(-1, 1, 1, 1, 1)
        zp_grid = zp.view(1, -1, 1, 1, 1)
        dot_q_q = kp.view(1, 1, -1, 1, 1)
        yq_grid = zp.view(1, 1, 1, -1, 1)
        zq_grid = zp.view(1, 1, 1, 1, -1)

        dot_p_bigp = 1j * cdse_data.big_m_inter * torch.sqrt(dot_p_p) * zp_grid
        dot_q_bigp = 1j * cdse_data.big_m_inter * torch.sqrt(dot_q_q) * zq_grid
        dot_p_q = torch.sqrt(dot_p_p) * torch.sqrt(dot_q_q) * (zp_grid * zq_grid + yq_grid * torch.sqrt(1 - zq_grid ** 2) * torch.sqrt(1 - zp_grid ** 2))
        dot_bigp_bigp = - cdse_data.big_m_inter ** 2

        diff2_pq = dot_p_p + dot_q_q - 2 * dot_p_q
        qsum_2 = dot_q_q + cdse_data.eta_inter ** 2 * dot_bigp_bigp + 2 * cdse_data.eta_inter * dot_q_bigp
        dot_psum_qsum = dot_p_q + cdse_data.eta_inter * dot_p_bigp + cdse_data.eta_inter * dot_q_bigp + cdse_data.eta_inter ** 2 * dot_bigp_bigp
        diffpq_qsum = dot_p_q + cdse_data.eta_inter * dot_p_bigp - dot_q_q - cdse_data.eta_inter * dot_q_bigp
        diffpq_psum = dot_p_p + cdse_data.eta_inter * dot_p_bigp - dot_p_q - cdse_data.eta_inter * dot_q_bigp
        psum_2 = dot_p_p + cdse_data.eta_inter ** 2 * dot_bigp_bigp + 2 * cdse_data.eta_inter * dot_p_bigp
        demon = qsum_2 * a.view(1, 1, nk, 1, nz) ** 2 + b.view(1, 1, nk, 1, nz) ** 2
        g_val = cdse_data._g(diff2_pq)
        proj_fa = dot_psum_qsum + 2 * diffpq_qsum * diffpq_psum / diff2_pq
        integrand_a = g_val * a.view(1, 1, nk, 1, nz) / demon * proj_fa
        integrand_b = g_val * b.view(1, 1, nk, 1, nz) / demon
        
        coeff_a = 4 * rdse_data.z2 ** 2 / (3 * psum_2.view(nk, nz)) * (2 * np.pi)**(-3)
        coeff_b = 4 * rdse_data.z2 ** 2 * (2 * np.pi)**(-3)

        # dq * dzq * sqrt(1-zq**2) * q
        # p, pz, q, qy, qz
        weight = kw.view(1, 1, -1, 1, 1) * zw.view(1, 1, 1, 1, -1) * dot_q_q * torch.sqrt(1 - zq_grid**2) * zw.view(1, 1, 1, -1, 1) / 2

        sum_a = torch.sum(integrand_a * weight, dim=(2, 3, 4))
        sum_b = torch.sum(integrand_b * weight, dim=(2, 3, 4)) 

        cdse_data.a_inter = rdse_data.z2 + coeff_a * sum_a
        cdse_data.b_inter = rdse_data.z4 * rdse_data.m + coeff_b * sum_b

        return None

    @staticmethod
    def iter_straight(rdse_data: RdseData, cdse_data: CdseData):
        CdseSolver.__cal_contour_init(cdse_data)
        error_curr = 100
        step = 0
        while error_curr > cdse_data.error:
            step = step + 1
            ap_old = cdse_data.a_inter.clone()
            bp_old = cdse_data.b_inter.clone()
            CdseSolver.__cal_a_b_straight(rdse_data = rdse_data, cdse_data = cdse_data)
            a_error = torch.mean(torch.abs(cdse_data.a_inter - ap_old))
            b_error = torch.mean(torch.abs(cdse_data.b_inter - bp_old))
            error_curr = a_error + b_error
            print(f"state:Complex DSE\tstep:{step}\terror:{error_curr}\tgoal:{cdse_data.error}")
        return None

    @staticmethod
    def cal_goal(data: CdseData, type: int = 4):
        # Goalp = torch(n, 4)

        if type == 4:
            dim = data.goal.shape[:-1] # (n,)最后一维4
            goal2 = torch.sum(data.goal ** 2, dim=(-1)).unsqueeze(-1) # (n,1)
        elif type == 2:
            dim = data.goal.shape # (n)
            goal2 = data.goal.unsqueeze(-1) # (n,1)
        else:   raise ValueError("type must be 2 or 4")

        factor_u = -1 - 1j * data.eta_contour * data.big_m_contour / torch.sqrt(data.kp_contour).view(*([1] * len(dim)), -1)
        factor_d = 1 - 1j * data.eta_contour * data.big_m_contour / torch.sqrt(data.kp_contour).view(*([1] * len(dim)), -1)
        factor_r = 1j * data.big_m_contour * np.sqrt(data.lambda_square) * 2 * data.eta_contour

        dot_qu_qu = data.kp_contour.view(*([1] * len(dim)), -1)
        dot_qd_qd = data.kp_contour.view(*([1] * len(dim)), -1)
        dot_qr_qr = data.lambda_square - 1 / data.lambda_square
        zqr_grid = data.zp_contour.view(*([1] * len(dim)), -1)
        dot_bigp_bigp = -data.big_m_contour ** 2

        dot_qu_bigp = 1j * torch.sqrt(dot_qu_qu) * data.big_m_contour
        dot_qd_bigp = -1j * torch.sqrt(dot_qd_qd) * data.big_m_contour
        dot_qr_bigp = 1j * np.sqrt(dot_qr_qr) * zqr_grid * data.big_m_contour

        qusum_2 = dot_qu_qu + data.eta_contour ** 2 * dot_bigp_bigp + 2 * data.eta_contour * dot_qu_bigp    # (1,m)
        qdsum_2 = dot_qd_qd + data.eta_contour ** 2 * dot_bigp_bigp + 2 * data.eta_contour * dot_qd_bigp
        qrsum_2 = dot_qr_qr + data.eta_contour ** 2 * dot_bigp_bigp + 2 * data.eta_contour * dot_qr_bigp

        weight_u = data.kw_contour.view(*([1] * len(dim)), -1) * factor_u
        weight_d = data.kw_contour.view(*([1] * len(dim)), -1) * factor_d
        weight_r = data.zw_contour.view(*([1] * len(dim)), -1) * factor_r

        demon_u = qusum_2 - goal2   #   (n,m)
        demon_d = qdsum_2 - goal2
        demon_r = qrsum_2 - goal2

        numer_a = torch.sum(data.a_up * weight_u / demon_u + data.a_down * weight_d / demon_d, dim=(-1)) + torch.sum(data.a_right * weight_r / demon_r, dim=(-1))
        numer_b = torch.sum(data.b_up * weight_u / demon_u + data.b_down * weight_d / demon_d, dim=(-1)) + torch.sum(data.b_right * weight_r / demon_r, dim=(-1))
        
        norm = torch.sum(weight_u / demon_u + weight_d / demon_d, dim=(-1)) + torch.sum(weight_r / demon_r, dim=(-1))

        data.a_goal = numer_a / norm
        data.b_goal = numer_b / norm

        return None
    
    @staticmethod
    def four_to_two_cooperate(data: CdseData):
        """
        将四维坐标转换成二维复平面坐标, 输出复平面位置
        """
        # Goalp = torch(n, 4)
        data.goal = torch.sum(data.goal ** 2, dim=(-1)) # (n,1)
        return None
    
