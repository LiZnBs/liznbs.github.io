# Python DSE Program

这是一个基于 Python 的 Dyson-Schwinger Equation 计算与绘图程序，主要用于处理实 DSE 相关的数据生成、数值求解与结果绘图。项目中包含参数配置、求解器、绘图工具以及示例脚本，适合用于数值实验、结果对比和图像输出。

## 配置
### 1.下载python
### 2.创建虚拟环境

进入项目目录后，先创建虚拟环境：

```bash
python3 -m venv .venv
source .venv/bin/activate
```

如果是 Windows：

```bash
python -m venv .venv
.venv\Scripts\activate
```

### 3.安装项目依赖

项目依赖记录在 `requirements.txt` 中，可直接执行：

```bash
pip3 install -r requirements.txt
```

如果是 Windows：

```bash
pip install -r requirements.txt
```

## 调库命令
### 导入项目主库

项目主库建议这样导入：

```python
import dse_storage as dse
```

这样后面可以直接调用项目中的类和函数，例如：

```python
data = dse.RdseData()
dse.RdseSolver.iter(data)
```
