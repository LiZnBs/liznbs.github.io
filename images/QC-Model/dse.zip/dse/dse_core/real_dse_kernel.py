# 参数包
from .real_dse_data import RdseData
import torch
import numpy as np
import torch.nn as nn

class RdseSolver:
    """
    实DSE方程求解器
    包含函数: iter()
    """
    @staticmethod
    def __cal_dse_ms(data: RdseData):
        """
        执行DSE函数
        自动输入: a, b
        更新: Z2, Z4, a, b
        动量减除重正化
        """
        
        kp = data.kp
        kw = data.kw
        a = data.a
        b = data.b
        w0_interp = data.w0_interp
        w1_interp = data.w1_interp
        renorm_pos = data.renorm_pos

        # p, q, zq
        dot_pp = kp.view(-1, 1, 1)
        dot_qq = kp.view(1, -1, 1)
        zq_grid = data.zp.view(1, 1, -1)

        dot_pq = torch.sqrt(dot_pp) * torch.sqrt(dot_qq) * zq_grid
        diff2_pq = dot_pp + dot_qq - 2 * dot_pq
        diff_dot_q = dot_pq - dot_qq
        diff_dot_p = dot_pp - dot_pq

        demon = dot_qq * a.view(1, -1, 1) ** 2 + b.view(1, -1, 1) ** 2
        g_val = data._g(diff2_pq)
        proj_fa = dot_pq + 2 * diff_dot_q * diff_dot_p / diff2_pq

        integrand_a = g_val * a.view(1, -1, 1) / demon * proj_fa
        integrand_b = g_val * b.view(1, -1, 1) / demon

        coeff_a = 4 / (3 * dot_pp.view(-1)) * (2 * np.pi)**(-3)
        coeff_b = 4 * (2 * np.pi)**(-3)
        
        # dq * dzq * sqrt(1-zq**2) * q
        # p, q, zq
        weight = kw.view(1, -1, 1) * data.zw.view(1, 1, -1) * dot_qq * torch.sqrt(1 - zq_grid**2)

        sum_a = torch.sum(integrand_a * weight, dim=(1, 2))
        sum_b = torch.sum(integrand_b * weight, dim=(1, 2))

        temp_ap = 1 + coeff_a * sum_a
        temp_bp = data.m + coeff_b * sum_b

        temp1 = w1_interp * temp_ap[renorm_pos+1] + w0_interp * temp_ap[renorm_pos]
        temp2 = w1_interp * temp_bp[renorm_pos+1] + w0_interp * temp_bp[renorm_pos]

        data.z2 = (2 - temp1).detach()
        data.z4 = (2 - temp2 / data.m).detach()
        data.a = (1 + temp_ap - temp1).detach()
        data.b = (data.m + temp_bp - temp2).detach()
    

        return None
    
    @staticmethod
    def __cal_dse_cl(data: RdseData):
        """
        执行DSE函数
        自动输入: a, b
        更新: Z2, Z4, a, b
        手征极限重正化
        """

        kp = data.kp
        kw = data.kw
        a = data.a
        b = data.b
        c = data.c
        d = data.d
        w0_interp = data.w0_interp
        w1_interp = data.w1_interp
        renorm_pos = data.renorm_pos

        # p, q, zq
        dot_pp = kp.view(-1, 1, 1)
        dot_qq = kp.view(1, -1, 1)
        zq_grid = data.zp.view(1, 1, -1)

        dot_pq = torch.sqrt(dot_pp) * torch.sqrt(dot_qq) * zq_grid
        diff2_pq = dot_pp + dot_qq - 2 * dot_pq
        diff_dot_q = dot_pq - dot_qq
        diff_dot_p = dot_pp - dot_pq

        demon = dot_qq * a.view(1, -1, 1) ** 2 + b.view(1, -1, 1) ** 2
        demon_2 = demon ** 2
        g_val = data._g(diff2_pq)
        proj_fa = dot_pq + 2 * diff_dot_q * diff_dot_p / diff2_pq
        
        num_c = c.view(1, -1, 1) * (b.view(1, -1, 1) ** 2 - dot_qq * a.view(1, -1, 1) ** 2) - 2 * a.view(1, -1, 1) * b.view(1, -1, 1) * d.view(1, -1, 1)
        num_d = b.view(1, -1, 1) ** 2 * d.view(1, -1, 1) + a.view(1, -1, 1) * (2 * b.view(1, -1, 1) * c.view(1, -1, 1) - a.view(1, -1, 1) * d.view(1, -1, 1)) * dot_qq

        integrand_a = g_val * a.view(1, -1, 1) / demon * proj_fa
        integrand_b = g_val * b.view(1, -1, 1) / demon
        integrand_c = g_val * num_c.view(1, -1, 1) / demon_2 * proj_fa
        integrand_d = g_val * num_d.view(1, -1, 1) / demon_2

        coeff_a = 4 / (3 * dot_pp.view(-1)) * (2 * np.pi)**(-3)
        coeff_b = 4 * (2 * np.pi)**(-3)
        
        # dq * dzq * sqrt(1-zq**2) * q
        # p, q, zq
        weight = kw.view(1, -1, 1) * data.zw.view(1, 1, -1) * dot_qq * torch.sqrt(1 - zq_grid**2)

        sum_a = torch.sum(integrand_a * weight, dim=(1, 2))
        sum_b = torch.sum(integrand_b * weight, dim=(1, 2))
        sum_c = torch.sum(integrand_c * weight, dim=(1, 2))
        sum_d = torch.sum(integrand_d * weight, dim=(1, 2))

        temp_ap = 1 + data.z2 ** 2 * coeff_a * sum_a
        temp_bp = data.z4 * data.m + data.z2 ** 2 * coeff_b * sum_b
        temp_cp = data.z2 ** 2 * coeff_a * sum_c
        temp_dp = 1 - data.z2 ** 2 * coeff_b * sum_d


        data.b = temp_bp.detach()
        data.c = temp_cp.detach()
        

        temp1 = w1_interp * temp_ap[renorm_pos+1] + w0_interp * temp_ap[renorm_pos]
        temp2 = w1_interp * temp_dp[renorm_pos+1] + w0_interp * temp_dp[renorm_pos]

        data.z2 = (2 - temp1).detach()
        data.z4 = (2 - temp2).detach()
        data.a = (1 + temp_ap - temp1).detach()
        data.d = (1 + temp_dp - temp2).detach()
        
        return None
    

    @staticmethod
    def iter(data: RdseData, renormalisation = 'ms'):
        """
        传入 RdseData, 迭代实DSE直到收敛
        ms: 动量减除; cl: 手征极限重正化
        """
        error_curr = 100
        step = 0
        if renormalisation == 'ms':
            while error_curr > data.error:
                step = step + 1
                ap_old = data.a.clone()
                bp_old = data.b.clone()
                RdseSolver.__cal_dse_ms(data = data)
                a_error = torch.mean(torch.abs(data.a - ap_old))
                b_error = torch.mean(torch.abs(data.b - bp_old))
                error_curr = a_error + b_error
                
                print(f"state:Real DSE\tstep:{step}\terror:{error_curr}\tgoal:{data.error}")
        elif renormalisation == 'cl':
            while error_curr > data.error:
                step = step + 1
                ap_old = data.a.clone()
                bp_old = data.b.clone()
                cp_old = data.c.clone()
                dp_old = data.d.clone()
                RdseSolver.__cal_dse_cl(data = data)
                a_error = torch.mean(torch.abs(data.a - ap_old))
                b_error = torch.mean(torch.abs(data.b - bp_old))
                c_error = torch.mean(torch.abs(data.c - cp_old))
                d_error = torch.mean(torch.abs(data.d - dp_old))
                error_curr = a_error + b_error + c_error + d_error

                print(f"state:Real DSE\tstep:{step}\terror:{error_curr}\tgoal:{data.error}")
        return None