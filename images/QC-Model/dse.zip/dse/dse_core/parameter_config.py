# 依赖包
import torch
from numpy.polynomial.legendre import leggauss
import numpy as np
from dataclasses import dataclass, field

torch.set_printoptions(precision=16)

@dataclass
class Config:

    # Parameters
    m: float = 0.0034
    omega: float = 0.5
    D: float = 1.024
    mt: float = 0.5
    lambda_square: int = 100**2
    mu: int = 19

    # Derived physical constants
    nf: int = 4
    lambda_qcd: float = 0.234
    __tau: float = field(default = np.exp(2) - 1, init = False)
    __gamma_m: float = field(init = False)

    def __post_init__(self):
        self.__gamma_m = 12 / (33 - 2 * self.nf)

    # Basis Config Functions
    def __f(self, k):
        val = (1 - torch.exp(-k / (4 * self.mt ** 2))) / k
        return val

    def __fuv(self, k):
        num = 8 * np.pi ** 2 * self.__gamma_m * self.__f(k)
        den = torch.log(self.__tau + (k / self.lambda_qcd ** 2 + 1) ** 2)
        return num / den
        
    def _g(self, k):
        """g(k)函数"""
        term_1 = self.D * 8 * np.pi ** 2 / (self.omega ** 4) * torch.exp(-k / self.omega ** 2)
        return term_1 + self.__fuv(k)

    def _create_legendre_kp(self, nk_input):
        """以gauss-legendre方法生成kp torch散点"""
        kp, kw = leggauss(nk_input)
        kp_temp = self.lambda_square ** kp
        kp = kp_temp - 1 / self.lambda_square #一个小平移减去红外保证围道积分准确
        kw = kw * kp_temp * np.log(self.lambda_square)
        kp = torch.tensor(kp, dtype=torch.float64)
        kw = torch.tensor(kw, dtype=torch.float64)
        return kp, kw

    def _create_legendre_zp(self, nz_input):
        """以gauss-legendre方法生成zp torch散点"""
        zp, zw = leggauss(nz_input)
        zp = torch.tensor(zp, dtype=torch.float64)
        zw = torch.tensor(zw, dtype=torch.float64)
        return zp, zw

    def _create_interp(self, kp_input, mu_input):
        """创建插值系数"""
        nk = kp_input.shape[0]
        pos = np.searchsorted(kp_input, mu_input ** 2) - 1
        if pos < 0: pos = 0
        if pos >= nk - 1: pos = nk - 2
        x0 = kp_input[pos]
        x1 = kp_input[pos+1]
        w0 = (x1 - mu_input ** 2) / (x1 - x0)
        w1 = (mu_input ** 2 - x0) / (x1 - x0)
        return pos, w0, w1
