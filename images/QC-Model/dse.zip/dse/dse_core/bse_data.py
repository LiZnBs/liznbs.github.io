# 参数包
from .parameter_config import Config
from .complex_dse_data import CdseData

# 依赖包
import torch
from dataclasses import dataclass, field, InitVar


@dataclass
class BseData(Config):

    # Initial
    base: InitVar[CdseData] = None

    # Normal Results
    error: float = 1e-7
    eigenvalue: torch.Tensor | None = field(default=None, init=False)
    eigenvector: torch.Tensor | None = field(default=None, init=False)
    kernel: torch.Tensor | None = field(default=None, init=False)

    def __post_init__(self, base: CdseData):
        super().__post_init__()
        self.eigenvalue = torch.tensor(1 + 1j, dtype=torch.complex128)
        self.eigenvector = torch.ones((base.nk_inter, base.nz_inter, 4), dtype=torch.complex128)
        self.kernel = torch.zeros((base.nk_inter, base.nz_inter, base.nk_inter, base.nz_inter, 4, 4), dtype=torch.complex128)