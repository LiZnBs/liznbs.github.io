# 参数包
from .parameter_config import Config

# 依赖包
import torch
from dataclasses import dataclass, field

@dataclass
class RdseData(Config):

    # Rdse Config
    nk: int = 100
    nz: int = 40
    error: float = 1e-16

    kp: torch.Tensor | None = field(default=None, init=False)
    kw: torch.Tensor | None = field(default=None, init=False)
    zp: torch.Tensor | None = field(default=None, init=False)
    zw: torch.Tensor | None = field(default=None, init=False)

    # Normal Results
    z2: float = field(default=1.0, init=False)    # cl 方法不能设置z2,z4初始值=0,会发散
    z4: float = field(default=1.0, init=False)

    a: torch.Tensor | None = field(default=None, init=False)
    b: torch.Tensor | None = field(default=None, init=False)
    c: torch.Tensor | None = field(default=None, init=False)
    d: torch.Tensor | None = field(default=None, init=False)

    renorm_pos: int = field(default=0, init=False)
    w0_interp: float = field(default=0.0, init=False)
    w1_interp: float = field(default=0.0, init=False)


    def __post_init__(self):
        super().__post_init__()
        self.kp, self.kw = self._create_legendre_kp(self.nk)
        self.zp, self.zw = self._create_legendre_zp(self.nz)
        
        self.a = torch.ones(self.nk, dtype=torch.float64)
        self.b = torch.ones(self.nk, dtype=torch.float64)

        self.c = torch.ones(self.nk, dtype=torch.float64)
        self.d = torch.ones(self.nk, dtype=torch.float64)
        
        self.renorm_pos, self.w0_interp, self.w1_interp = self._create_interp(self.kp, self.mu)