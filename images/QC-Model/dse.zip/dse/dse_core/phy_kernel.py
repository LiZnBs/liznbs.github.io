import torch
import numpy as np
from .real_dse_data import RdseData
from .complex_dse_data import CdseData
from .bse_data import BseData
from .phy_data import PhyData

class PhySolver:

    @staticmethod
    def __ldc_kernel(cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData):
        k = cdse1_data.kp_inter.view(-1, 1)
        p = cdse1_data.big_m_inter
        kz = cdse1_data.zp_inter.view(1, -1)
        
        apu = cdse1_data.a_inter.detach().clone()
        bpu = cdse1_data.b_inter.detach().clone()
        ams = cdse2_data.a_inter.detach().clone().flip(1)
        bms = cdse2_data.b_inter.detach().clone().flip(1)

        f1 = bse_data.eigenvector[:, :, 0]
        f2 = bse_data.eigenvector[:, :, 1]
        f3 = bse_data.eigenvector[:, :, 2]
        f4 = bse_data.eigenvector[:, :, 3]

        pairpp = -p ** 2
        pairkp = 1j * kz * torch.sqrt(k) * p
        pair_k_k = k
        return (16*(4*(apu*bms - ams*bpu)*f1*pairkp + pairpp*(2*apu*bms*f1 + 2*ams*bpu*f1 - 4*bms*bpu*f2 + 4*(ams*apu*f2 + apu*bms*f4 + ams*bpu*f4)*pair_k_k + ams*apu*f2*pairpp) - pow(pairkp,2)*(8*ams*apu*f2 + 4*bms*bpu*f3 + 4*apu*bms*f4 + 4*ams*bpu*f4 + 4*ams*apu*f3*pair_k_k - ams*apu*f3*pairpp)))/((4*pow(bms,2) + 4*pow(ams,2)*pair_k_k - 4*pow(ams,2)*pairkp + pow(ams,2)*pairpp)*(4*pow(bpu,2) + 4*pow(apu,2)*pair_k_k + 4*pow(apu,2)*pairkp + pow(apu,2)*pairpp))

    @staticmethod
    def __vqc_kernel(cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData):
        k = cdse1_data.kp_inter.view(-1, 1)
        p = cdse1_data.big_m_inter
        kz = cdse1_data.zp_inter.view(1, -1)
        
        apu = cdse1_data.a_inter.detach().clone()
        bpu = cdse1_data.b_inter.detach().clone()
        ams = cdse2_data.a_inter.detach().clone().flip(1)
        bms = cdse2_data.b_inter.detach().clone().flip(1)

        f1 = bse_data.eigenvector[:, :, 0]
        f2 = bse_data.eigenvector[:, :, 1]
        f3 = bse_data.eigenvector[:, :, 2]
        f4 = bse_data.eigenvector[:, :, 3]
        pairpp = -p ** 2
        pairkp=1j*kz*torch.sqrt(k) * p
        pair_k_k=k
        return (16*(4*bms*bpu*f1 + 4*(apu*bms - ams*bpu)*f2*pairkp + 2*(apu*bms*f3 + ams*bpu*f3 + 2*ams*apu*f4)*pairkp**2 - ams*apu*f1*pairpp + 2*apu*bms*f2*pairpp + 2*ams*bpu*f2*pairpp + 4*pair_k_k*((apu*bms - ams*bpu)*f3*pairkp + ams*apu*(f1 - f4*pairpp))))/((4*bms**2 + 4*ams**2*pair_k_k - 4*ams**2*pairkp + ams**2*pairpp)*(4*bpu**2 + 4*apu**2*pair_k_k + 4*apu**2*pairkp + apu**2*pairpp))

    @staticmethod
    def ldc(rdse1_data: RdseData, rdse2_data: RdseData, cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData, phy_data: PhyData):

        term = PhySolver.__ldc_kernel(cdse1_data, cdse2_data, bse_data)

        kq_torch = cdse1_data.kp_inter.view(-1, 1)
        qw_torch = cdse1_data.kw_inter.view(-1, 1)
        qz_torch = cdse1_data.zp_inter.view(1, -1)
        qzw_torch = cdse1_data.zw_inter.view(1, -1)

        weight = (2 * np.pi) ** (-3) * qw_torch * kq_torch * qzw_torch * torch.sqrt(1 - qz_torch ** 2)

        phy_data.lepton_decay_constant = torch.sum(weight * term) * torch.sqrt(rdse1_data.z2 * rdse2_data.z2) * 3 / (-cdse1_data.big_m_inter ** 2)
        return None

    @staticmethod
    def vqc(rdse1_data: RdseData, rdse2_data: RdseData, cdse1_data: CdseData, cdse2_data: CdseData, bse_data: BseData, phy_data: PhyData):

        term = PhySolver.__vqc_kernel(cdse1_data, cdse2_data, bse_data)

        kq_torch = cdse1_data.kp_inter.view(-1, 1)
        qw_torch = cdse1_data.kw_inter.view(-1, 1)
        qz_torch = cdse1_data.zp_inter.view(1, -1)
        qzw_torch = cdse1_data.zw_inter.view(1, -1)

        weight = (2 * np.pi) ** (-3) * qw_torch * kq_torch * qzw_torch * torch.sqrt(1 - qz_torch ** 2)

        phy_data.vacuum_quark_condensation = torch.sum(weight * term) * torch.sqrt(rdse1_data.z4 * rdse2_data.z4) * 3
        return None
