import dse_core as dse

# real dse
rdse = dse.RdseData()
dse.RdseSolver.iter(rdse)
# print(rdse.a)

# complex dse
cdse = dse.CdseData()
dse.CdseSolver.iter(rdse, cdse)
# print(cdse.a_up)

# bse
bse = dse.BseData(base = cdse)
dse.BseSolver.iter(rdse, rdse, cdse, cdse, bse)
# print(bse.eigenvalue)

# normalization
cdse_norm = dse.CdseData(big_m_contour = 1.00001 * cdse.big_m_inter)
dse.CdseSolver.iter(rdse, cdse_norm)
dse.BseSolver.norm(cdse, cdse, cdse_norm, cdse_norm, bse)

# physical quantity calculation
phy_data = dse.PhyData()
dse.PhySolver.ldc(rdse, rdse, cdse, cdse, bse, phy_data)
dse.PhySolver.vqc(rdse, rdse, cdse, cdse, bse, phy_data)
# print(phy_data.lepton_decay_constant)
# print(phy_data.vacuum_quark_condensation)

# save
dse.save_data(rdse, './data', 'rdse')
dse.save_data(cdse, './data', 'cdse')
dse.save_data(bse, './data', 'bse')
dse.save_data(phy_data, './data', 'phy_data')

# load
rdse = dse.RdseData()
dse.load_data('./data', 'rdse', rdse, rdse=rdse)
cdse = dse.CdseData()
dse.load_data('./data', 'cdse', cdse, cdse=cdse)
bse = dse.BseData(base = cdse)
dse.load_data('./data', 'bse', bse, bse=bse)
phy_data = dse.PhyData()
dse.load_data('./data', 'phy_data', phy_data, phy_data=phy_data)

print(rdse.z2)
print(cdse.a_up)
print(bse.eigenvalue)
print(phy_data.lepton_decay_constant)
print(phy_data.vacuum_quark_condensation)
