#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_ROOT="$SCRIPT_DIR/MDPI_PIC_PROJECT"
OUT_DIR="$SCRIPT_DIR/Fig"

mkdir -p "$OUT_DIR"

# 删除目标目录中的旧图片/PDF
find "$OUT_DIR" -maxdepth 1 -type f -iname "*.pdf" -delete

# 复制 Fig1.pdf ~ Fig15.pdf 到目标目录
for i in $(seq 1 15); do
    SRC_PDF="$SRC_ROOT/Fig${i}/Result/Fig${i}.pdf"
    if [ ! -f "$SRC_PDF" ]; then
        echo "Missing source file: $SRC_PDF" >&2
        exit 1
    fi
    cp "$SRC_PDF" "$OUT_DIR/Fig${i}.pdf"
done

echo "Done: copied Fig1.pdf ~ Fig15.pdf to $OUT_DIR"
