#!/bin/bash

# 主文件夹路径
main_dir="$(dirname "$0")"

# 查找主文件夹下名字包含 "result" 的文件夹
find "$main_dir" -type d -name "*alpha*" | while read -r folder; do
    echo "正在处理文件夹: $folder"
    # 检查文件夹名称是否包含 "-y" 或 "-n"
    if [[ "$folder" != *"_y" && "$folder" != *"_n" && "$folder" != *"_x"* ]]; then
        echo "正在处理文件夹: $folder"

        # 查找文件夹中的 .png 图片
        img=$(find "$folder" -maxdepth 1 -type f -name "*.png" | head -n 1)

            if [ -n "$img" ]; then
                echo "打开图片: $img"
                xdg-open "$img" >/dev/null 2>&1 # 确保 xdg-open 不干扰输入

                # 等待用户输入字符串
                echo "请输入要添加到文件夹名 'result' 后的字符串:"
                read -r suffix < /dev/tty # 强制从终端读取输入

                # 检查用户是否输入了内容
                while [ -z "$suffix" ]; do
                    echo "输入不能为空，请重新输入:"
                    read -r suffix < /dev/tty
                done

                # 强制关闭图片查看器
                pkill -f "$(basename "$img")"
            else
            echo "文件夹中没有找到 .png 图片，跳过..."
            continue
            fi

            # 获取父目录路径和当前文件夹名
            parent_dir=$(dirname "$folder")
            base_name=$(basename "$folder")

            # 构造新的文件夹名
            new_name="${base_name}_$suffix"
            new_folder="$parent_dir/$new_name"

            # 重命名文件夹
            mv "$folder" "$new_folder"
            echo "文件夹已重命名为: $new_folder"
    else
    echo "跳过文件夹: $folder（包含 '-y' 或 '-n'）"
    fi
done
find . -type d -name "*_x*" -exec rm -rf {} \;
echo "所有文件夹处理完成！"